"""Create safe local demo accounts and one sample shipment for GlobalTrack.
Run: python3 setup_demo.py
These credentials are for local demonstration only; change them before production.
"""
from app import app, get_db, init_db
from werkzeug.security import generate_password_hash
from datetime import datetime

# ================= ADMIN CREDENTIALS =================
# Change these two values to your own admin login before running setup_demo.py.
ADMIN_EMAIL = "admin@globaltrack.test"
ADMIN_PASSWORD = "Admin123!"

DEMO_USERS = [
    ("Demo", "Customer", "customer@globaltrack.test", "08000000001", "Customer", "Customer123!"),
    ("Demo", "Agent", "agent@globaltrack.test", "08000000002", "Delivery Agent", "Agent123!"),
    ("Demo", "Admin", ADMIN_EMAIL, "08000000003", "Admin", ADMIN_PASSWORD),
]

with app.app_context():
    init_db()
    db = get_db()
    for first, last, email, phone, role, password in DEMO_USERS:
        existing = db.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone()
        if not existing:
            db.execute("INSERT INTO users (first_name,last_name,email,phone,password_hash,account_type,created_at) VALUES (?,?,?,?,?,?,?)",
                       (first,last,email,phone,generate_password_hash(password),role,datetime.utcnow().isoformat(timespec="seconds")))
    db.commit()
    customer = db.execute("SELECT id FROM users WHERE email=?", ("customer@globaltrack.test",)).fetchone()
    agent = db.execute("SELECT id FROM users WHERE email=?", ("agent@globaltrack.test",)).fetchone()
    shipment = db.execute("SELECT id FROM shipments WHERE tracking_number='GT-DEMO-001'").fetchone()
    if not shipment:
        cur = db.execute("""INSERT INTO shipments
            (tracking_number,customer_id,agent_id,service,sender_name,sender_phone,sender_address,
             recipient_name,recipient_phone,recipient_address,package_type,weight_kg,status,created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            ('GT-DEMO-001', customer['id'], agent['id'], 'Express', 'Demo Customer', '08000000001', 'Port Harcourt, Nigeria',
             'Demo Recipient', '08000000004', 'Lagos, Nigeria', 'Electronics', 2.5, 'Pending Pickup', datetime.utcnow().isoformat(timespec='seconds')))
        db.execute("INSERT INTO tracking_events (shipment_id,status,location,description,created_at) VALUES (?,?,?,?,?)",
                   (cur.lastrowid,'Pending Pickup','Port Harcourt, Nigeria','Demo shipment is ready for pickup.',datetime.utcnow().isoformat(timespec='seconds')))
        db.commit()
    print("Demo setup complete.")
    print("Customer: customer@globaltrack.test / Customer123!")
    print("Agent:    agent@globaltrack.test / Agent123!")
    print(f"Admin:    {ADMIN_EMAIL} / {ADMIN_PASSWORD}")
    print("Tracking: GT-DEMO-001")
