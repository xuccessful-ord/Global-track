"""Create a local GlobalTrack administrator for development/testing.

Run with: python create_admin.py
"""
from getpass import getpass
import sqlite3
from datetime import datetime
from werkzeug.security import generate_password_hash

first = input("First name: ").strip()
last = input("Last name: ").strip()
email = input("Email: ").strip().lower()
phone = input("Phone: ").strip()
password = getpass("Password (8+ characters): ")

if not all([first, last, email, phone, password]) or len(password) < 8:
    raise SystemExit("All fields are required and the password must contain at least 8 characters.")

db = sqlite3.connect("globaltrack.db")
try:
    db.execute(
        """INSERT INTO users
        (first_name,last_name,email,phone,password_hash,account_type,created_at)
        VALUES (?,?,?,?,?,?,?)""",
        (first, last, email, phone, generate_password_hash(password), "Admin", datetime.utcnow().isoformat(timespec="seconds")),
    )
    db.commit()
except sqlite3.IntegrityError:
    raise SystemExit("That email already exists. Update the existing user's account_type to 'Admin' instead.")
finally:
    db.close()

print("Administrator account created successfully.")
