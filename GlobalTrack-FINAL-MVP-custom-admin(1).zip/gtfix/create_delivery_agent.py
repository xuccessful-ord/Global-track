"""Create a local delivery-agent account for GlobalTrack testing.

Usage:
    python create_delivery_agent.py

This script is intentionally separate from app.py so production deployments do
not automatically create privileged accounts.
"""
from getpass import getpass
import sqlite3
from datetime import datetime
from werkzeug.security import generate_password_hash

DATABASE = "globaltrack.db"

first = input("First name: ").strip()
last = input("Last name: ").strip()
email = input("Email: ").strip().lower()
phone = input("Phone: ").strip()
password = getpass("Password (8+ characters): ")

if not all([first, last, email, phone, password]) or len(password) < 8:
    raise SystemExit("All fields are required and the password must contain at least 8 characters.")

db = sqlite3.connect(DATABASE)
try:
    db.execute(
        """INSERT INTO users
        (first_name,last_name,email,phone,password_hash,account_type,created_at)
        VALUES (?,?,?,?,?,?,?)""",
        (first, last, email, phone, generate_password_hash(password), "Delivery Agent", datetime.utcnow().isoformat(timespec="seconds")),
    )
    db.commit()
except sqlite3.IntegrityError:
    raise SystemExit("That email already exists. Change the account type of the existing user to 'Delivery Agent' instead.")
finally:
    db.close()

print("Delivery-agent account created successfully.")
