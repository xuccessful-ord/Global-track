const menuToggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".main-nav");

if (menuToggle) {
  menuToggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(open));
  });
}

document.querySelectorAll(".main-nav a").forEach(link => {
  link.addEventListener("click", () => {
    nav.classList.remove("open");
    menuToggle?.setAttribute("aria-expanded", "false");
  });
});

const trackingForm = document.getElementById("trackingForm");
const trackingInput = document.getElementById("trackingNumber");
const formMessage = document.getElementById("formMessage");

trackingForm?.addEventListener("submit", (event) => {
  const value = trackingInput.value.trim();
  if (!value) {
    event.preventDefault();
    formMessage.textContent = "Please enter a tracking number to continue.";
    formMessage.style.color = "#f0c66f";
    trackingInput.focus();
  }
});
