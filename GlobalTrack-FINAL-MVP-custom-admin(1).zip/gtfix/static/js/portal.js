document.querySelectorAll('.menu-toggle').forEach(toggle => {
  toggle.addEventListener('click', () => {
    const nav = toggle.parentElement.querySelector('.main-nav');
    const open = nav?.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(!!open));
  });
});

document.querySelectorAll('.show-password').forEach(button => {
  button.addEventListener('click', () => {
    const input = document.getElementById(button.dataset.target);
    if (!input) return;
    const visible = input.type === 'text';
    input.type = visible ? 'password' : 'text';
    button.textContent = visible ? 'SHOW' : 'HIDE';
  });
});

const shipmentForm = document.getElementById('shipmentForm');
if (shipmentForm) {
  const servicePrices = {'Express International':48,'Standard Delivery':32,'Economy':21};
  const serviceDays = {'Express International':'2–4 days','Standard Delivery':'5–8 days','Economy':'7–12 days'};
  const updateEstimate = () => {
    const service = document.querySelector('input[name="service"]:checked')?.value || 'Express International';
    const packageType = document.getElementById('packageType')?.value || 'Document';
    const weight = Number(document.getElementById('weight')?.value || 1);
    const extra = Math.max(0, weight - 1) * 6;
    document.getElementById('estimateService').textContent = service;
    document.getElementById('estimatePackage').textContent = packageType;
    document.getElementById('estimateWeight').textContent = `${weight} kg`;
    document.getElementById('estimateDays').textContent = serviceDays[service];
    document.getElementById('estimateCost').textContent = `$${(servicePrices[service] + extra).toFixed(2)}`;
  };
  shipmentForm.querySelectorAll('input[name="service"]').forEach(input => input.addEventListener('change', updateEstimate));
  document.getElementById('packageType')?.addEventListener('change', updateEstimate);
  document.getElementById('weight')?.addEventListener('input', updateEstimate);
}
