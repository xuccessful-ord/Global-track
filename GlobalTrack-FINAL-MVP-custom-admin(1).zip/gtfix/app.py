"""GlobalTrack Flask application.

This version adds the second backend slice: public tracking, shipment details,
customer shipment history, and account notifications.
"""
from functools import wraps
import os
import sqlite3
from datetime import datetime, timedelta
from secrets import token_hex
from urllib.parse import urlparse
from flask import Flask, flash, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATABASE = os.path.join(BASE_DIR, "globaltrack.db")
app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("GLOBALTRACK_SECRET", "globaltrack-dev-secret-change-in-production")
app.config["DATABASE"] = DATABASE
# Keep the login session alive between page requests and browser navigation.
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(days=7)
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
# Local development uses HTTP, so Secure must remain False here. Enable it behind HTTPS in production.
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("GLOBALTRACK_HTTPS", "0") == "1"
app.config["SESSION_REFRESH_EACH_REQUEST"] = True
app.config["SESSION_COOKIE_NAME"] = "globaltrack_session"
app.config["SESSION_COOKIE_PATH"] = "/"
app.config["SESSION_COOKIE_DOMAIN"] = None

def get_db():
    """Return one SQLite connection for the current HTTP request."""
    if "db" not in g:
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()

def init_db():
    """Create tables if they do not already exist."""
    db = get_db()
    db.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT, first_name TEXT NOT NULL,
        last_name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, phone TEXT NOT NULL,
        password_hash TEXT NOT NULL, account_type TEXT NOT NULL DEFAULT 'Customer',
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS shipments (
        id INTEGER PRIMARY KEY AUTOINCREMENT, tracking_number TEXT NOT NULL UNIQUE,
        customer_id INTEGER NOT NULL, service TEXT NOT NULL, sender_name TEXT NOT NULL,
        sender_phone TEXT NOT NULL, sender_address TEXT NOT NULL,
        recipient_name TEXT NOT NULL, recipient_phone TEXT NOT NULL,
        recipient_address TEXT NOT NULL, package_type TEXT NOT NULL, weight_kg REAL NOT NULL,
        status TEXT NOT NULL DEFAULT 'Pending Pickup', created_at TEXT NOT NULL,
        FOREIGN KEY (customer_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS tracking_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT, shipment_id INTEGER NOT NULL,
        status TEXT NOT NULL, location TEXT NOT NULL, description TEXT NOT NULL,
        created_at TEXT NOT NULL, FOREIGN KEY (shipment_id) REFERENCES shipments(id)
    );
    CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
        title TEXT NOT NULL, message TEXT NOT NULL, is_read INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL, FOREIGN KEY (user_id) REFERENCES users(id)
    );
    """)
    # Lightweight migration for databases created by earlier GlobalTrack versions.
    columns = {row["name"] for row in db.execute("PRAGMA table_info(shipments)").fetchall()}
    if "agent_id" not in columns:
        db.execute("ALTER TABLE shipments ADD COLUMN agent_id INTEGER REFERENCES users(id)")
    db.commit()

def safe_next_url(target):
    """Allow only local relative redirects after login."""
    if not target:
        return None
    parsed = urlparse(target)
    if parsed.scheme or parsed.netloc:
        return None
    return target if target.startswith("/") else None

@app.before_request
def refresh_authenticated_user():
    """Keep the session tied to a real database user on every request."""
    user_id = session.get("user_id")
    if not user_id:
        return
    user = get_db().execute("SELECT id, first_name, account_type FROM users WHERE id=?", (user_id,)).fetchone()
    if user is None:
        session.clear()
        return
    session.permanent = True
    session["user_name"] = user["first_name"]
    session["account_type"] = user["account_type"]

def login_required(view):
    @wraps(view)
    def wrapped_view(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped_view

def role_required(*allowed_roles):
    """Allow a page only to users with one of the supplied account roles."""
    def decorator(view):
        @wraps(view)
        def wrapped_view(*args, **kwargs):
            if "user_id" not in session:
                return redirect(url_for("login", next=request.path))
            if session.get("account_type") not in allowed_roles:
                return ("You do not have permission to access this page.", 403)
            return view(*args, **kwargs)
        return wrapped_view
    return decorator

def agent_required(view):
    """Shortcut for delivery-agent-only routes."""
    return role_required("Delivery Agent")(view)

def add_tracking_event(db, shipment_id, status, location, description):
    """Record a shipment status change as an immutable timeline event."""
    db.execute("INSERT INTO tracking_events (shipment_id,status,location,description,created_at) VALUES (?,?,?,?,?)",
               (shipment_id, status, location, description, datetime.utcnow().isoformat(timespec="seconds")))

def add_notification(db, user_id, title, message):
    db.execute("INSERT INTO notifications (user_id,title,message,created_at) VALUES (?,?,?,?)",
               (user_id, title, message, datetime.utcnow().isoformat(timespec="seconds")))

@app.route("/")
def home(): return render_template("index.html")

@app.route("/login.html", methods=["GET", "POST"])
def login():
    if request.method == "GET" and session.get("user_id"):
        account_type = session.get("account_type")
        if account_type == "Delivery Agent":
            return redirect(url_for("delivery_agent_dashboard"))
        if account_type == "Admin":
            return redirect(url_for("admin_dashboard"))
        return redirect(url_for("customer_dashboard"))
    if request.method == "POST":
        email=request.form.get("email","").strip().lower(); password=request.form.get("password","")
        user=get_db().execute("SELECT * FROM users WHERE email=?",(email,)).fetchone()
        if not user or not check_password_hash(user["password_hash"], password):
            return render_template("login.html", error="Invalid email or password.")
        session.clear()
        session.permanent = True
        session["user_id"] = user["id"]
        session["user_name"] = user["first_name"]
        session["account_type"] = user["account_type"]
        next_url = safe_next_url(request.args.get("next"))
        if user["account_type"] == "Delivery Agent":
            destination = url_for("delivery_agent_dashboard")
        elif user["account_type"] == "Admin":
            destination = url_for("admin_dashboard")
        else:
            destination = url_for("customer_dashboard")
        return redirect(next_url or destination)
    return render_template("login.html", error=None)

@app.route("/register.html", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        fields=("first_name","last_name","email","phone","password","account_type")
        data={k:request.form.get(k,"").strip() for k in fields}
        allowed_account_types={"Customer","Business"}
        if data.get("account_type") not in allowed_account_types:
            return render_template("register.html", error="Please choose a valid customer account type.")
        if not all(data.values()): return render_template("register.html", error="Please complete every required field.")
        if request.form.get("terms_accepted") != "on":
            return render_template("register.html", error="You must accept the terms and privacy policy.")
        if len(data["password"])<8: return render_template("register.html", error="Password must contain at least 8 characters.")
        try:
            db=get_db(); db.execute("INSERT INTO users (first_name,last_name,email,phone,password_hash,account_type,created_at) VALUES (?,?,?,?,?,?,?)",
                (data["first_name"],data["last_name"],data["email"].lower(),data["phone"],generate_password_hash(data["password"]),data["account_type"],datetime.utcnow().isoformat(timespec="seconds"))); db.commit()
        except sqlite3.IntegrityError: return render_template("register.html", error="An account with that email already exists.")
        return redirect(url_for("login", registered="1"))
    return render_template("register.html", error=None)

@app.route("/logout")
def logout(): session.clear(); return redirect(url_for("home"))

@app.route("/customer-dashboard.html")
@login_required
def customer_dashboard():
    db=get_db(); uid=session["user_id"]
    shipments=db.execute("SELECT * FROM shipments WHERE customer_id=? ORDER BY id DESC LIMIT 5",(uid,)).fetchall()
    counts=db.execute("SELECT COUNT(*) AS total, COALESCE(SUM(CASE WHEN status IN ('Pending Pickup','Picked Up','In Transit') THEN 1 ELSE 0 END),0) AS active, COALESCE(SUM(CASE WHEN status='Delivered' THEN 1 ELSE 0 END),0) AS delivered FROM shipments WHERE customer_id=?",(uid,)).fetchone()
    return render_template("customer-dashboard.html",shipments=shipments,counts=counts)

@app.route("/create-shipment.html", methods=["GET","POST"])
@login_required
def create_shipment():
    if request.method=="POST":
        fields=["service","sender_name","sender_phone","sender_address","recipient_name","recipient_phone","recipient_address","package_type","weight"]
        data={f:request.form.get(f,"").strip() for f in fields}
        if not all(data.values()): return render_template("create-shipment.html",error="Please complete all shipment fields.")
        try: weight=float(data["weight"]); assert weight>0
        except (ValueError,AssertionError): return render_template("create-shipment.html",error="Weight must be a positive number.")
        tracking="GT-"+datetime.utcnow().strftime("%y%m%d")+"-"+token_hex(3).upper(); db=get_db()
        cur=db.execute("INSERT INTO shipments (tracking_number,customer_id,service,sender_name,sender_phone,sender_address,recipient_name,recipient_phone,recipient_address,package_type,weight_kg,status,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (tracking,session["user_id"],data["service"],data["sender_name"],data["sender_phone"],data["sender_address"],data["recipient_name"],data["recipient_phone"],data["recipient_address"],data["package_type"],weight,"Pending Pickup",datetime.utcnow().isoformat(timespec="seconds")))
        add_tracking_event(db,cur.lastrowid,"Pending Pickup",data["sender_address"],"Shipment was created and is waiting for pickup.")
        add_notification(db,session["user_id"],"Shipment created",f"{tracking} is ready for pickup.")
        db.commit(); return redirect(url_for("customer_dashboard",created=tracking))
    return render_template("create-shipment.html",error=None)

@app.route("/track.html", methods=["GET","POST"])
def track():
    tracking=(request.form.get("tracking_number") if request.method=="POST" else request.args.get("tracking_number","" )).strip().upper()
    shipment=None; events=[]; error=None
    if tracking:
        shipment=get_db().execute("SELECT * FROM shipments WHERE tracking_number=?",(tracking,)).fetchone()
        if shipment: events=get_db().execute("SELECT * FROM tracking_events WHERE shipment_id=? ORDER BY id DESC",(shipment["id"],)).fetchall()
        else: error="We could not find a shipment with that tracking number."
    return render_template("track.html",shipment=shipment,events=events,error=error,tracking_number=tracking)

@app.route("/shipment/<tracking_number>")
def shipment_details(tracking_number):
    db=get_db(); shipment=db.execute("SELECT * FROM shipments WHERE tracking_number=?",(tracking_number.upper(),)).fetchone()
    if not shipment: return render_template("shipment-details.html",shipment=None),404
    events=db.execute("SELECT * FROM tracking_events WHERE shipment_id=? ORDER BY id DESC",(shipment["id"],)).fetchall()
    return render_template("shipment-details.html",shipment=shipment,events=events)

@app.route("/shipment-history.html")
@login_required
def shipment_history():
    db=get_db(); shipments=db.execute("SELECT * FROM shipments WHERE customer_id=? ORDER BY id DESC",(session["user_id"],)).fetchall()
    return render_template("shipment-history.html",shipments=shipments)

@app.route("/notifications.html")
@login_required
def notifications():
    db=get_db(); rows=db.execute("SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC",(session["user_id"],)).fetchall()
    return render_template("notifications.html",notifications=rows)

@app.post("/notifications/mark-all-read")
@login_required
def mark_all_notifications_read():
    db=get_db(); db.execute("UPDATE notifications SET is_read=1 WHERE user_id=?",(session["user_id"],)); db.commit()
    return redirect(url_for("notifications"))

@app.post("/notifications/<int:notification_id>/read")
@login_required
def mark_notification_read(notification_id):
    db=get_db(); db.execute("UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?",(notification_id,session["user_id"])); db.commit()
    return redirect(url_for("notifications"))

@app.route("/delivery-agent-dashboard.html")
@agent_required
def delivery_agent_dashboard():
    db = get_db()
    agent_id = session["user_id"]
    shipments = db.execute(
        """SELECT * FROM shipments WHERE agent_id=? ORDER BY id DESC LIMIT 10""",
        (agent_id,),
    ).fetchall()
    stats = db.execute(
        """SELECT
           COUNT(*) AS total,
           SUM(CASE WHEN status IN ('Picked Up','In Transit','Arrived at Destination','Out for Delivery','Delayed') THEN 1 ELSE 0 END) AS active,
           SUM(CASE WHEN status='Delivered' THEN 1 ELSE 0 END) AS delivered
           FROM shipments WHERE agent_id=?""",
        (agent_id,),
    ).fetchone()
    return render_template("delivery-agent-dashboard.html", shipments=shipments, stats=stats)

@app.route("/agent-shipments.html")
@agent_required
def agent_shipments():
    db = get_db()
    shipments = db.execute(
        "SELECT * FROM shipments WHERE agent_id=? ORDER BY id DESC",
        (session["user_id"],),
    ).fetchall()
    return render_template("agent-shipments.html", shipments=shipments)

@app.route("/agent-shipment/<tracking_number>")
@agent_required
def agent_shipment(tracking_number):
    db = get_db()
    shipment = db.execute(
        "SELECT * FROM shipments WHERE tracking_number=? AND agent_id=?",
        (tracking_number.upper(), session["user_id"]),
    ).fetchone()
    if not shipment:
        return "Shipment not found or not assigned to you.", 404
    events = db.execute(
        "SELECT * FROM tracking_events WHERE shipment_id=? ORDER BY id DESC",
        (shipment["id"],),
    ).fetchall()
    return render_template("agent-shipment.html", shipment=shipment, events=events)

@app.post("/agent-shipment/<tracking_number>/status")
@agent_required
def update_agent_status(tracking_number):
    db = get_db()
    shipment = db.execute(
        "SELECT * FROM shipments WHERE tracking_number=? AND agent_id=?",
        (tracking_number.upper(), session["user_id"]),
    ).fetchone()
    if not shipment:
        return "Shipment not found or not assigned to you.", 404
    allowed_transitions = {
        "In Transit": {"Out for Delivery", "Arrived at Destination", "Delayed"},
        "Arrived at Destination": {"Out for Delivery", "Delivery Attempted", "Delayed"},
        "Out for Delivery": {"Delivered", "Delivery Attempted", "Delayed"},
        "Delivery Attempted": {"Out for Delivery", "Delivered", "Delayed"},
        "Delayed": {"In Transit", "Out for Delivery", "Delayed"},
    }
    status = request.form.get("status", "").strip()
    location = request.form.get("location", "Agent checkpoint").strip() or "Agent checkpoint"
    note = request.form.get("note", "Shipment status updated by delivery agent.").strip() or "Shipment status updated by delivery agent."
    if status not in allowed_transitions.get(shipment["status"], set()):
        flash(f"Cannot change shipment from {shipment['status']} to {status}.", "error")
        return redirect(url_for("agent_shipment", tracking_number=tracking_number))
    db.execute("UPDATE shipments SET status=? WHERE id=?", (status, shipment["id"]))
    add_tracking_event(db, shipment["id"], status, location, note)
    add_notification(db, shipment["customer_id"], "Shipment update", f"{shipment['tracking_number']} is now {status}.")
    db.commit()
    flash("Shipment status updated successfully.", "success")
    return redirect(url_for("agent_shipment", tracking_number=tracking_number))

@app.route("/pickup-confirmation/<tracking_number>", methods=["GET", "POST"])
@agent_required
def pickup_confirmation(tracking_number):
    db = get_db()
    shipment = db.execute(
        "SELECT * FROM shipments WHERE tracking_number=? AND agent_id=?",
        (tracking_number.upper(), session["user_id"]),
    ).fetchone()
    if not shipment:
        return "Shipment not found or not assigned to you.", 404
    if request.method == "POST":
        if shipment["status"] != "Pending Pickup":
            return render_template("pickup-confirmation.html", shipment=shipment, error="Pickup can only be confirmed while the shipment is pending pickup.")
        checks = [request.form.get("package_checked"), request.form.get("sealed"), request.form.get("sender_verified"), request.form.get("location_confirmed")]
        if not all(checks):
            return render_template("pickup-confirmation.html", shipment=shipment, error="Complete every pickup verification item before confirming.")
        note = request.form.get("notes", "Pickup completed and package verified.").strip() or "Pickup completed and package verified."
        db.execute("UPDATE shipments SET status='In Transit' WHERE id=?", (shipment["id"],))
        add_tracking_event(db, shipment["id"], "In Transit", shipment["sender_address"], note)
        add_notification(db, shipment["customer_id"], "Shipment picked up", f"{shipment['tracking_number']} has been picked up and is now in transit.")
        db.commit()
        return redirect(url_for("agent_shipment", tracking_number=shipment["tracking_number"]))
    return render_template("pickup-confirmation.html", shipment=shipment, error=None)

@app.route("/delivery-confirmation/<tracking_number>", methods=["GET", "POST"])
@agent_required
def delivery_confirmation(tracking_number):
    db = get_db()
    shipment = db.execute(
        "SELECT * FROM shipments WHERE tracking_number=? AND agent_id=?",
        (tracking_number.upper(), session["user_id"]),
    ).fetchone()
    if not shipment:
        return "Shipment not found or not assigned to you.", 404
    if request.method == "POST":
        if shipment["status"] not in {"Out for Delivery", "Arrived at Destination", "Delivery Attempted"}:
            return render_template("delivery-confirmation.html", shipment=shipment, error="The shipment must be out for delivery before it can be completed.")
        recipient = request.form.get("recipient", "").strip()
        proof = request.form.get("proof")
        notes = request.form.get("notes", "Delivery completed.").strip() or "Delivery completed."
        if not recipient or not proof:
            return render_template("delivery-confirmation.html", shipment=shipment, error="Recipient verification and proof of delivery are required.")
        db.execute("UPDATE shipments SET status='Delivered' WHERE id=?", (shipment["id"],))
        add_tracking_event(db, shipment["id"], "Delivered", shipment["recipient_address"], notes)
        add_notification(db, shipment["customer_id"], "Shipment delivered", f"{shipment['tracking_number']} has been delivered successfully.")
        db.commit()
        return redirect(url_for("agent_shipment", tracking_number=shipment["tracking_number"]))
    return render_template("delivery-confirmation.html", shipment=shipment, error=None)

@app.route("/profile-settings.html")
@login_required
def profile_settings():
    return render_template("profile-settings.html")

@app.route("/support.html")
@login_required
def support():
    return render_template("support.html")

def admin_required(view):
    return role_required("Admin")(view)

@app.route("/admin-dashboard.html")
@admin_required
def admin_dashboard():
    db = get_db()
    stats = db.execute("""SELECT
        COUNT(*) AS total,
        COALESCE(SUM(CASE WHEN status NOT IN ('Delivered') THEN 1 ELSE 0 END),0) AS active,
        COALESCE(SUM(CASE WHEN status='Delivered' THEN 1 ELSE 0 END),0) AS delivered
        FROM shipments""").fetchone()
    users = db.execute("SELECT COUNT(*) AS total, COALESCE(SUM(account_type IN ('Customer','Business')),0) AS customers, COALESCE(SUM(account_type='Delivery Agent'),0) AS agents, COALESCE(SUM(account_type='Admin'),0) AS admins FROM users").fetchone()
    recent = db.execute("SELECT * FROM shipments ORDER BY id DESC LIMIT 8").fetchall()
    return render_template("admin-dashboard.html", stats=stats, users=users, recent=recent)

@app.route("/admin-shipments.html")
@admin_required
def admin_shipments():
    db = get_db()
    shipments = db.execute("""SELECT s.*, u.first_name || ' ' || u.last_name AS customer_name,
        a.first_name || ' ' || a.last_name AS agent_name
        FROM shipments s JOIN users u ON u.id=s.customer_id
        LEFT JOIN users a ON a.id=s.agent_id ORDER BY s.id DESC""").fetchall()
    agents = db.execute("SELECT id, first_name, last_name FROM users WHERE account_type='Delivery Agent' ORDER BY first_name").fetchall()
    return render_template("admin-shipments.html", shipments=shipments, agents=agents)

@app.post("/admin/shipments/<int:shipment_id>/assign")
@admin_required
def assign_agent(shipment_id):
    db = get_db()
    agent_id = request.form.get("agent_id", type=int)
    shipment = db.execute("SELECT * FROM shipments WHERE id=?", (shipment_id,)).fetchone()
    agent = db.execute("SELECT * FROM users WHERE id=? AND account_type='Delivery Agent'", (agent_id,)).fetchone() if agent_id else None
    if not shipment or not agent:
        flash("Select a valid delivery agent and shipment.", "error")
        return redirect(url_for("admin_shipments"))
    db.execute("UPDATE shipments SET agent_id=? WHERE id=?", (agent_id, shipment_id))
    add_notification(db, agent_id, "New shipment assigned", f"Shipment {shipment['tracking_number']} has been assigned to you.")
    db.commit()
    flash("Delivery agent assigned successfully.", "success")
    return redirect(url_for("admin_shipments"))

@app.route("/admin-users.html")
@admin_required
def admin_users():
    db = get_db()
    users = db.execute("SELECT id, first_name, last_name, email, phone, account_type, created_at FROM users ORDER BY id DESC").fetchall()
    return render_template("admin-users.html", users=users)

@app.route("/<path:page>")
def frontend_page(page):
    # Only public prototype pages are allowed through this fallback route.
    # Protected pages have explicit routes above so they cannot be bypassed.
    public_pages={"index.html","login.html","register.html","track.html"}
    if page in public_pages:
        return render_template(page)
    return ("Page not found",404)

with app.app_context(): init_db()

if __name__=="__main__": app.run(debug=True)
