# GlobalTrack — Final MVP

GlobalTrack is a Flask + SQLite shipping management system designed as an interview-ready logistics project.

## Core workflow

Customer registers/logs in → creates shipment → receives tracking number → tracks shipment.

Admin logs in → views shipments/users → assigns a delivery agent.

Delivery agent logs in → sees assigned shipment → confirms pickup → updates status → confirms delivery.

Every important status change is stored in `tracking_events`, and customers receive notifications.

## Technology

- **Frontend:** HTML5, CSS3, JavaScript
- **Backend:** Python + Flask
- **Database:** SQLite
- **Authentication:** Flask sessions + Werkzeug password hashing
- **Templates:** Jinja2

## Project structure

```text
GlobalTrack/
├── app.py
├── setup_demo.py
├── create_admin.py
├── create_delivery_agent.py
├── requirements.txt
├── globaltrack.db
├── templates/
└── static/
    ├── css/       # one dedicated stylesheet per page
    └── js/
```

## Run locally

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python3 setup_demo.py
python3 app.py
```

Open `http://127.0.0.1:5000`.

## Demo accounts

- Customer: `customer@globaltrack.test` / `Customer123!`
- Delivery Agent: `agent@globaltrack.test` / `Agent123!`
- Admin: `admin@globaltrack.test` / `Admin123!`
- Tracking number: `GT-DEMO-001`

These are **local demo credentials only**. Do not use them in production.

## Interview explanation

### Authentication
Flask receives the login request, looks up the user by email, verifies the password hash, then stores the user ID and role in the signed Flask session cookie. Protected routes check that session before serving the page.

### Shipment tracking
A shipment has a current status, while every status change is also stored as a tracking event. This preserves the shipment history instead of overwriting the previous state.

### Role-based access
Customer, Delivery Agent and Admin routes are protected server-side. The UI is not the security boundary; Flask checks the user's role before allowing access.

### Database design
Users own shipments. Shipments can be assigned to delivery agents. Tracking events belong to shipments, and notifications belong to users. Foreign keys enforce these relationships in SQLite.

## Production improvements

Before production deployment, replace the development secret, enable HTTPS-only cookies, add CSRF protection, add database migrations, configure a production WSGI server, and move sensitive configuration into environment variables.
